

package fawry.internship;

import static com.sun.org.apache.xalan.internal.xsltc.compiler.util.Type.String;


public class TV extends products{
    
    private int screensize;

    public TV(java.lang.String model, double price, int stock,int screensize) {
        super(model, price, stock);
        
        this.screensize=screensize;
    }

  
       
    
    
    
    
    
}
